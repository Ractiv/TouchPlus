﻿TouchPlusDLL

This project will construct the Touch Plus DLL for win32. The result of the build will be a .DLL file. A simple demonstration of using this SDK is the Ractiv-Viewer_win32 project.
