# Ractiv-Viewer_win32
A basic viewer for Touch Plus utilizing the windows SDK

This project demonstrates the use of the Ractiv Win32 SDK. Please note that the TouchPlusDLL project must be built first. The resulting .DLL file is used for this viewer.
